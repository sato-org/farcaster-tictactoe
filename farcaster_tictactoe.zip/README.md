# Farcaster Tic Tac Toe Frame

This is a simple miniapp for Farcaster that lets users play Tic Tac Toe.

## How to deploy

1. Push this code to your GitHub repository.
2. Connect your repo to [Vercel](https://vercel.com) and deploy.
3. Share the live link in your Farcaster post using frame metadata.